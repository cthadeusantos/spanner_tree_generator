import os
import sys

from pathlib import Path

def ler_arquivo(arquivo):
  """
  Lê um arquivo 0.out.txt e retorna um dicionário com os dados.
  """
  dados = {}
  with open(arquivo, "r") as f:
    for linha in f:
      if "=" in linha:
        chave, valor = linha.split("=")
        chave = chave.strip().replace(".", "")
        valor = valor.strip()
        dados[chave] = valor
  return dados

def gerar_tabela(diretorio, arquivo_saida):
  """
  Gera uma tabela a partir dos arquivos 0.out.txt nos subdiretórios.
  """
  cabecalho = list()
  dados = []
  counter = 0
  for subdir in os.listdir(diretorio):
    arquivo = Path(diretorio) / subdir / "0.out.txt"
    if arquivo.is_file():
      dados_arquivo = ler_arquivo(arquivo)
      if dados_arquivo:
        if counter == 0:
            cabecalho.append(dados_arquivo.keys())
        dados.append(dados_arquivo)
    counter += 1
  # Escreve a tabela no arquivo de saída
  with open(arquivo_saida, "w") as f:
    cabecalho = list(cabecalho[0])
    f.write(", ".join(cabecalho) + "\n")
    for linha in dados:
      f.write(", ".join(linha.values()) + "\n")


if __name__ == "__main__":
  # Diretório raiz passado como argumento
  diretorio_raiz = sys.argv[1]
  arquivo_saida = "summary_table.txt"

  gerar_tabela(diretorio_raiz, arquivo_saida)

  print(f"Tabela gerada com sucesso em {arquivo_saida}")

