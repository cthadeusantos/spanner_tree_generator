python3 execution-battery.py 1 < batteries/07-balanced-ADJACENCY.yaml
python3 execution-battery.py 1 < batteries/07-balanced-EDGE.yaml
python3 execution-battery.py 1 < batteries/07-balanced-CYCLE2-edge.yaml
python3 execution-battery.py 1 < batteries/07-balanced-CYCLE1-edge.yaml
