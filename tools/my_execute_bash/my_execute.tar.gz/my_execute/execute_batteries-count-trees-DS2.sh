python3 execution-battery.py 1 < batteries/05-count-trees-CYCLE2-edge.yaml
python3 execution-battery.py 1 < batteries/06-count-trees-EDGE.yaml
python3 execution-battery.py 1 < batteries/06-count-trees-CYCLE-edge.yaml
python3 execution-battery.py 1 < batteries/06-count-trees-CYCLE2-edge.yaml
python3 execution-battery.py 1 < batteries/06-count-trees-ADJACENCY.yaml
python3 execution-battery.py 1 < batteries/06-count-trees-SEQ.yaml
