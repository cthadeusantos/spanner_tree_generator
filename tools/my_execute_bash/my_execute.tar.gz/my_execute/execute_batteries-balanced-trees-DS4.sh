python3 execution-battery.py 1 < batteries/10-balanced-SEQUENTIAL.yaml
python3 execution-battery.py 1 < batteries/10-balanced-ADJACENCY.yaml
python3 execution-battery.py 1 < batteries/10-balanced-EDGE.yaml
python3 execution-battery.py 1 < batteries/10-balanced-CYCLE2-edge.yaml
python3 execution-battery.py 1 < batteries/10-balanced-CYCLE1-edge.yaml
