python3 execution-battery.py 1 < batteries/04-one-hour-EDGE.yaml
python3 execution-battery.py 1 < batteries/04-one-hour-CYCLE-edge.yaml
python3 execution-battery.py 1 < batteries/04-one-hour-ADJACENCY.yaml
python3 execution-battery.py 1 < batteries/04-one-hour-SEQ.yaml
