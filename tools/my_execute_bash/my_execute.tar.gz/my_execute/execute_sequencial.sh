#python3 execution-battery.py 1 < batteries/01-ct-bf-inducedM4.yaml
#python3 execution-battery.py 1 < batteries/01-ct-bf-inducedM4-G19-8a64.yaml
#python3 execution-battery.py 1 < batteries/0000-ct-bf-par_v1.yaml
#python3 execution-battery.py 1 < batteries/0000-ct-bf-degree_v1.yaml
python3 execution-battery.py 1 < batteries/0000-ct-bf-seq_v1.yaml
