#python3 execution-battery.py 1 < batteries/01-ct-bf-inducedM4.yaml
#python3 execution-battery.py 1 < batteries/01-ct-bf-inducedM4-G19-8a64.yaml
python3 execution-battery.py 1 < batteries/0000-ct-bf-induced-ci1.yaml
python3 execution-battery.py 1 < batteries/0000-ct-bf-induced-ci2.yaml
python3 execution-battery.py 1 < batteries/0000-ct-bf-adjacency.yaml
python3 execution-battery.py 1 < batteries/0000-ct-bf-edges.yaml
python3 execution-battery.py 1 < batteries/0000-bf-seq.yaml
