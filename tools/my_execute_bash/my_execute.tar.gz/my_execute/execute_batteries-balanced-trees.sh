python3 execution-battery.py 1 < batteries/08-balanced-EDGE.yaml
python3 execution-battery.py 1 < batteries/08-balanced-CYCLE2-edge.yaml
python3 execution-battery.py 1 < batteries/08-balanced-ADJACENCY.yaml
python3 execution-battery.py 1 < batteries/08-balanced-CYCLE1-edge.yaml
python3 execution-battery.py 1 < batteries/09-balanced-EDGE.yaml
python3 execution-battery.py 1 < batteries/09-balanced-CYCLE2-edge.yaml
python3 execution-battery.py 1 < batteries/09-balanced-ADJACENCY.yaml
python3 execution-battery.py 1 < batteries/09-balanced-CYCLE1-edge.yaml
